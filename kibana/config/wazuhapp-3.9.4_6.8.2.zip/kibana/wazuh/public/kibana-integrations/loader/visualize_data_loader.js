"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Licensed to Elasticsearch B.V. under one or more contributor
 * license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright
 * ownership. Elasticsearch B.V. licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
// @ts-ignore
const lodash_1 = require("lodash");
// @ts-ignore
const vis_request_handlers_1 = require("ui/registry/vis_request_handlers");
// @ts-ignore
const vis_response_handlers_1 = require("ui/registry/vis_response_handlers");
// @ts-ignore No typing present
const elasticsearch_errors_1 = require("ui/elasticsearch_errors");
// @ts-ignore
const notify_1 = require("ui/notify");
// @ts-ignore
const timezone_1 = require("ui/vis/lib/timezone");
// @ts-ignore
const timefilter_1 = require("ui/timefilter");
// @ts-ignore
const es_query_1 = require("@kbn/es-query");
// @ts-ignore
const validate_interval_1 = require("./validate_interval");
function getHandler(from, type) {
    if (typeof type === 'function') {
        return type;
    }
    const handlerDesc = from.find(handler => handler.name === type);
    if (!handlerDesc) {
        throw new Error(`Could not find handler "${type}".`);
    }
    return handlerDesc.handler;
}
class VisualizeDataLoader {
    constructor(vis, Private, $injector) {
        this.vis = vis;
        const { requestHandler, responseHandler } = vis.type;
        const requestHandlers = Private(vis_request_handlers_1.VisRequestHandlersRegistryProvider);
        const responseHandlers = Private(vis_response_handlers_1.VisResponseHandlersRegistryProvider);
        if (((vis || {}).type || {}).title === 'Visual Builder') {
            const config = $injector.get('config');
            const discoverPendingUpdates = $injector.get('discoverPendingUpdates');
            const $http = $injector.get('$http');
            const buildEsQuery = Private(es_query_1.BuildESQueryProvider);
            this.requestHandler = ({ uiState, timeRange, filters, query, visParams }) => {
                const timezone = Private(timezone_1.timezoneProvider)();
                return new Promise((resolve) => {
                    const discoverList = discoverPendingUpdates.getList();
                    try {
                        if ((discoverList || []).length >= 2) {
                            const implicitFilter = (discoverList || []).length ? discoverList[0].query : '';
                            const parsedQuery = {
                                language: discoverList[0].language || 'lucene',
                                query: implicitFilter
                            };
                            const parsedFilters = discoverList[1];
                            query = parsedQuery;
                            filters = parsedFilters;
                        }
                    }
                    catch (error) { }
                    const panel = visParams;
                    const uiStateObj = {};
                    const parsedTimeRange = timefilter_1.timefilter.calculateBounds(timeRange);
                    const scaledDataFormat = config.get('dateFormat:scaled');
                    const dateFormat = config.get('dateFormat');
                    if (panel && panel.id) {
                        const params = {
                            timerange: { timezone, ...parsedTimeRange },
                            filters: [buildEsQuery(undefined, [query], filters)],
                            panels: [panel],
                            state: uiStateObj
                        };
                        try {
                            const maxBuckets = config.get('metrics:max_buckets');
                            validate_interval_1.validateInterval(parsedTimeRange, panel, maxBuckets);
                            const httpResult = $http.post('../api/metrics/vis/data', params)
                                .then(resp => ({ dateFormat, scaledDataFormat, timezone, ...resp.data }))
                                .catch(resp => { throw resp.data; });
                            return httpResult
                                .then(resolve)
                                .catch(resp => {
                                resolve({});
                                const err = new Error(resp.message);
                                err.stack = resp.stack;
                            });
                        }
                        catch (e) {
                            return resolve();
                        }
                    }
                });
            };
        }
        else {
            this.requestHandler = getHandler(requestHandlers, requestHandler);
        }
        this.responseHandler = getHandler(responseHandlers, responseHandler);
    }
    async fetch(params) {
        this.vis.filters = { timeRange: params.timeRange };
        this.vis.requestError = undefined;
        this.vis.showRequestError = false;
        try {
            // Vis types that have a `showMetricsAtAllLevels` param (e.g. data table) should tell
            // tabify whether to return columns for each bucket based on the param value. Vis types
            // without this param should default to returning all columns if they are hierarchical.
            const minimalColumns = typeof this.vis.params.showMetricsAtAllLevels !== 'undefined'
                ? !this.vis.params.showMetricsAtAllLevels
                : !this.vis.isHierarchical();
            const filters = params.filters || [];
            const savedFilters = params.searchSource.getField('filter') || [];
            const query = params.query || params.searchSource.getField('query');
            // searchSource is only there for courier request handler
            const requestHandlerResponse = await this.requestHandler({
                partialRows: this.vis.type.requiresPartialRows || this.vis.params.showPartialRows,
                minimalColumns,
                metricsAtAllLevels: this.vis.isHierarchical(),
                visParams: this.vis.params,
                ...params,
                query,
                filters: filters.concat(savedFilters).filter(f => !f.meta.disabled),
            });
            // No need to call the response handler when there have been no data nor has been there changes
            // in the vis-state (response handler does not depend on uiStat
            const canSkipResponseHandler = this.previousRequestHandlerResponse &&
                this.previousRequestHandlerResponse === requestHandlerResponse &&
                this.previousVisState &&
                lodash_1.isEqual(this.previousVisState, this.vis.getState());
            this.previousVisState = this.vis.getState();
            this.previousRequestHandlerResponse = requestHandlerResponse;
            if (!canSkipResponseHandler) {
                this.visData = await Promise.resolve(this.responseHandler(requestHandlerResponse));
            }
            return this.visData;
        }
        catch (error) {
            params.searchSource.cancelQueued();
            this.vis.requestError = error;
            this.vis.showRequestError =
                error.type && ['NO_OP_SEARCH_STRATEGY', 'UNSUPPORTED_QUERY'].includes(error.type);
            // tslint:disable-next-line
            console.error(error);
            if (elasticsearch_errors_1.isTermSizeZeroError(error)) {
                return notify_1.toastNotifications.addDanger(`Your visualization ('${this.vis.title}') has an error: it has a term ` +
                    `aggregation with a size of 0. Please set it to a number greater than 0 to resolve ` +
                    `the error.`);
            }
            notify_1.toastNotifications.addDanger({
                title: 'Error in visualization',
                text: error.message,
            });
        }
    }
}
exports.VisualizeDataLoader = VisualizeDataLoader;
